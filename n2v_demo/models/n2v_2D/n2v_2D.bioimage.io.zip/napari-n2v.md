## Noise2Void - 2D RGB Example
This network was trained using [napari-n2v](https://pypi.org/project/napari-n2v/).

## Cite Noise2Void - 2D RGB Example
A. Krull, T.-O. Buchholz and F. Jug, "Noise2Void - Learning Denoising From Single Noisy Images," 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition  (CVPR), 2019, pp. 2124-2132